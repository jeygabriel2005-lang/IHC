export type ViewportMode = 'desktop' | 'tablet' | 'mobile';

export interface HotlinkImage {
  id: string;
  url: string;
  title: string;
  category: 'avatar' | 'hero' | 'product' | 'architecture' | 'abstract';
  aspectRatio?: string;
  source?: string;
}

export interface AppScreen {
  id: string;
  title: string;
  description: string;
  category: string;
  badge?: string;
  hotlinkImages: HotlinkImage[];
}

export interface AppSuite {
  id: string;
  name: string;
  tagline: string;
  themeColor: string;
  accentBg: string;
  screens: AppScreen[];
}

export interface ExtractedHtmlData {
  rawHtml: string;
  title?: string;
  imageUrls: string[];
  headings: string[];
  links: string[];
  paragraphs: string[];
  buttonTexts: string[];
  parsedAt: Date;
}
