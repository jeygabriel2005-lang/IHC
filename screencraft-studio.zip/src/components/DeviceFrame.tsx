import React from 'react';
import { ViewportMode } from '../types';
import { Laptop, Tablet, Smartphone, Maximize2, ZoomIn, ZoomOut } from 'lucide-react';

interface DeviceFrameProps {
  mode: ViewportMode;
  scale: number;
  bgTheme: 'slate' | 'charcoal' | 'cream' | 'grid';
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({
  mode,
  scale,
  bgTheme,
  children,
}) => {
  const bgStyles = {
    slate: 'bg-slate-100',
    charcoal: 'bg-slate-900',
    cream: 'bg-[#faf8f5]',
    grid: 'bg-slate-100 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:16px_16px]',
  };

  return (
    <div className={`w-full min-h-[calc(100vh-130px)] p-3 sm:p-6 flex items-start justify-center overflow-auto transition-colors duration-300 ${bgStyles[bgTheme]}`}>
      <div 
        className="transition-transform duration-200 origin-top flex justify-center w-full"
        style={{ transform: `scale(${scale})` }}
      >
        {/* Desktop Viewport */}
        {mode === 'desktop' && (
          <div className="w-full max-w-7xl bg-white rounded-2xl shadow-xl border border-slate-200/90 overflow-hidden flex flex-col">
            {/* Browser top chrome */}
            <div className="h-10 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between px-4 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-400 border border-rose-500/30" />
                <div className="w-3 h-3 rounded-full bg-amber-400 border border-amber-500/30" />
                <div className="w-3 h-3 rounded-full bg-emerald-400 border border-emerald-500/30" />
              </div>
              <div className="bg-white px-6 py-1 rounded-md text-[11px] font-mono text-slate-500 border border-slate-200 flex items-center gap-2 shadow-2xs">
                <span className="text-emerald-500 font-bold">https://</span>
                <span>screencraft.preview.local</span>
              </div>
              <div className="w-12 text-right text-[10px] text-slate-400 font-mono">1440px</div>
            </div>
            <div className="bg-white min-h-[600px] overflow-x-hidden">
              {children}
            </div>
          </div>
        )}

        {/* Tablet Viewport (iPad Pro 768px) */}
        {mode === 'tablet' && (
          <div className="w-[768px] bg-slate-800 rounded-[38px] p-4 shadow-2xl border-4 border-slate-700 shrink-0">
            {/* Tablet status bar */}
            <div className="h-6 bg-slate-900 rounded-t-[24px] px-6 flex items-center justify-between text-[11px] text-slate-400">
              <span>9:41 AM</span>
              <div className="w-16 h-2.5 bg-slate-800 rounded-full" />
              <span>100%</span>
            </div>
            <div className="bg-white rounded-[24px] overflow-hidden min-h-[700px] max-h-[820px] overflow-y-auto">
              {children}
            </div>
          </div>
        )}

        {/* Mobile Viewport (iPhone 16 Pro 393px) */}
        {mode === 'mobile' && (
          <div className="w-[393px] bg-slate-900 rounded-[48px] p-3 shadow-2xl border-4 border-slate-800 shrink-0">
            {/* Dynamic Island & Status Bar */}
            <div className="relative h-8 bg-slate-900 rounded-t-[36px] flex items-center justify-between px-6 text-white text-[11px] font-medium">
              <span>9:41</span>
              {/* Dynamic Island capsule */}
              <div className="absolute left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full flex items-center justify-end pr-2">
                <div className="w-2 h-2 rounded-full bg-slate-800" />
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px]">5G</span>
                <div className="w-4 h-2 rounded-xs border border-white flex p-0.5">
                  <div className="w-full h-full bg-white rounded-2xs" />
                </div>
              </div>
            </div>
            
            {/* Screen Content Container */}
            <div className="bg-white rounded-[36px] overflow-hidden min-h-[740px] max-h-[740px] overflow-y-auto scrollbar-none">
              {children}
            </div>

            {/* Home indicator bar */}
            <div className="h-5 flex items-center justify-center">
              <div className="w-32 h-1 bg-slate-600 rounded-full" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
