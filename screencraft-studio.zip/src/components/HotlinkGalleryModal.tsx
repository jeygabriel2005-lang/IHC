import React, { useState } from 'react';
import { 
  X, Image as ImageIcon, Copy, Check, Plus, ExternalLink, 
  Search, Sparkles, Filter, Code
} from 'lucide-react';
import { POPULAR_HOTLINK_PRESETS } from '../data/sampleSuites';
import { HotlinkImage } from '../types';

interface HotlinkGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSuiteImages: HotlinkImage[];
  onAddCustomHotlink?: (url: string, title: string) => void;
}

export const HotlinkGalleryModal: React.FC<HotlinkGalleryModalProps> = ({
  isOpen,
  onClose,
  activeSuiteImages,
  onAddCustomHotlink,
}) => {
  const [activeTab, setActiveTab] = useState<'current' | 'presets' | 'custom'>('current');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [customUrl, setCustomUrl] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [filterQuery, setFilterQuery] = useState('');

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (customUrl.trim() && onAddCustomHotlink) {
      onAddCustomHotlink(customUrl.trim(), customTitle.trim() || 'Custom Hotlinked Image');
      setCustomUrl('');
      setCustomTitle('');
      setActiveTab('current');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Hotlinked Asset Library</h2>
              <p className="text-xs text-slate-500">
                Explore, copy, and link high-resolution CDN assets across your app screens.
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="px-6 pt-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('current')}
              className={`pb-3 text-xs font-semibold border-b-2 transition ${activeTab === 'current' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
            >
              Current Screen Assets ({activeSuiteImages.length})
            </button>
            <button
              onClick={() => setActiveTab('presets')}
              className={`pb-3 text-xs font-semibold border-b-2 transition ${activeTab === 'presets' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
            >
              Curated Photo Presets
            </button>
            <button
              onClick={() => setActiveTab('custom')}
              className={`pb-3 text-xs font-semibold border-b-2 transition ${activeTab === 'custom' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
            >
              + Add Custom Hotlink
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Current Screen Assets */}
          {activeTab === 'current' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {activeSuiteImages.map((img) => (
                  <div key={img.id} className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between group hover:border-indigo-300 transition">
                    <div className="relative aspect-video bg-slate-200 overflow-hidden">
                      <img src={img.url} alt={img.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                      <span className="absolute top-2 left-2 bg-slate-900/80 text-white text-[10px] px-2 py-0.5 rounded capitalize">
                        {img.category}
                      </span>
                    </div>
                    <div className="p-3">
                      <div className="font-semibold text-xs text-slate-900 truncate mb-1">{img.title}</div>
                      <div className="text-[10px] font-mono text-slate-500 truncate mb-3">{img.url}</div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleCopy(img.url, img.id)}
                          className="flex-1 py-1 px-2 bg-white hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 text-xs font-medium rounded border border-slate-200 transition flex items-center justify-center gap-1"
                        >
                          {copiedKey === img.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === img.id ? 'Copied' : 'Copy URL'}</span>
                        </button>
                        <button
                          onClick={() => handleCopy(`<img src="${img.url}" alt="${img.title}" class="w-full rounded-xl" />`, `${img.id}-tag`)}
                          className="py-1 px-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium rounded transition"
                          title="Copy <img> HTML tag"
                        >
                          <Code className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Curated Presets */}
          {activeTab === 'presets' && (
            <div className="space-y-8">
              {POPULAR_HOTLINK_PRESETS.map((presetGroup, idx) => (
                <div key={idx} className="space-y-3">
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    {presetGroup.category}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {presetGroup.items.map((item, itemIdx) => {
                      const key = `${idx}-${itemIdx}`;
                      return (
                        <div key={itemIdx} className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between">
                          <img src={item.url} alt={item.name} className="aspect-video w-full object-cover" />
                          <div className="p-3">
                            <div className="text-xs font-semibold text-slate-900 truncate mb-2">{item.name}</div>
                            <button
                              onClick={() => handleCopy(item.url, key)}
                              className="w-full py-1.5 bg-white hover:bg-indigo-50 hover:text-indigo-600 border border-slate-200 rounded text-xs font-semibold text-slate-700 transition flex items-center justify-center gap-1"
                            >
                              {copiedKey === key ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedKey === key ? 'Copied Hotlink' : 'Copy Hotlink'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add Custom Hotlink */}
          {activeTab === 'custom' && (
            <form onSubmit={handleAddCustom} className="max-w-lg mx-auto bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
              <h3 className="font-bold text-slate-900 text-sm">Attach a Hotlink Image URL</h3>
              <p className="text-xs text-slate-500">Enter any publicly accessible image URL (Unsplash, Cloudinary, AWS S3, etc.).</p>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Image URL</label>
                <input
                  type="url"
                  required
                  placeholder="https://images.unsplash.com/photo-..."
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Asset Title / Caption</label>
                <input
                  type="text"
                  placeholder="e.g. Modern Architecture Concept"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {customUrl && (
                <div className="pt-2">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">Live Image Preview:</span>
                  <img 
                    src={customUrl} 
                    alt="Preview" 
                    className="aspect-video w-full object-cover rounded-xl border border-slate-200"
                    onError={(e) => {
                      (e.target as HTMLImageElement).alt = 'Image URL could not be loaded';
                    }}
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
              >
                Save to Hotlink Registry
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
