import React from 'react';
import { 
  Laptop, Tablet, Smartphone, Code, Image as ImageIcon, 
  Palette, ChevronDown, Sparkles, Layers, RefreshCw
} from 'lucide-react';
import { AppSuite, AppScreen, ViewportMode } from '../types';

interface TopNavProps {
  suites: AppSuite[];
  activeSuite: AppSuite;
  onSelectSuite: (suiteId: string) => void;
  activeScreen: AppScreen;
  onSelectScreen: (screenId: string) => void;
  viewportMode: ViewportMode;
  onSetViewportMode: (mode: ViewportMode) => void;
  zoomScale: number;
  onSetZoomScale: (scale: number) => void;
  bgTheme: 'slate' | 'charcoal' | 'cream' | 'grid';
  onSetBgTheme: (theme: 'slate' | 'charcoal' | 'cream' | 'grid') => void;
  onOpenImporterModal: () => void;
  onOpenHotlinksModal: () => void;
  hotlinksCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  suites,
  activeSuite,
  onSelectSuite,
  activeScreen,
  onSelectScreen,
  viewportMode,
  onSetViewportMode,
  zoomScale,
  onSetZoomScale,
  bgTheme,
  onSetBgTheme,
  onOpenImporterModal,
  onOpenHotlinksModal,
  hotlinksCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 shadow-2xs">
      {/* Top Primary Bar */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand & Suite Switcher */}
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Layers className="w-5 h-5" />
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
              ScreenCraft Studio
            </span>
            <div className="relative group">
              <select
                value={activeSuite.id}
                onChange={(e) => onSelectSuite(e.target.value)}
                className="font-bold text-slate-900 text-sm bg-transparent cursor-pointer pr-6 focus:outline-none appearance-none hover:text-indigo-600 transition"
              >
                {suites.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-0 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Viewport & Canvas Controls Center */}
        <div className="hidden md:flex items-center gap-3">
          {/* Viewport Mode Buttons */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              onClick={() => onSetViewportMode('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewportMode === 'desktop' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
              title="Desktop 1440px"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>Desktop</span>
            </button>
            <button
              onClick={() => onSetViewportMode('tablet')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewportMode === 'tablet' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
              title="iPad Tablet 768px"
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>Tablet</span>
            </button>
            <button
              onClick={() => onSetViewportMode('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewportMode === 'mobile' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
              title="iPhone Mobile 393px"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile</span>
            </button>
          </div>

          {/* Zoom scale selector */}
          <div className="flex items-center bg-slate-100 px-2 py-1 rounded-xl text-[11px] font-mono text-slate-600">
            {[0.75, 1].map((scale) => (
              <button
                key={scale}
                onClick={() => onSetZoomScale(scale)}
                className={`px-2 py-0.5 rounded-md transition ${zoomScale === scale ? 'bg-white text-slate-900 font-bold shadow-2xs' : 'hover:text-slate-900'}`}
              >
                {Math.round(scale * 100)}%
              </button>
            ))}
          </div>

          {/* Canvas backdrop themes */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            {(['slate', 'charcoal', 'cream', 'grid'] as const).map((thm) => (
              <button
                key={thm}
                onClick={() => onSetBgTheme(thm)}
                className={`w-5 h-5 rounded-md border transition ${bgTheme === thm ? 'ring-2 ring-indigo-500 ring-offset-1' : 'opacity-70 hover:opacity-100'} ${thm === 'slate' ? 'bg-slate-200 border-slate-300' : thm === 'charcoal' ? 'bg-slate-900 border-slate-800' : thm === 'cream' ? 'bg-[#faf8f5] border-stone-300' : 'bg-slate-100 border-dashed border-slate-400'}`}
                title={`Canvas theme: ${thm}`}
              />
            ))}
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenHotlinksModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition shadow-2xs"
          >
            <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
            <span>Hotlinks ({hotlinksCount})</span>
          </button>

          <button
            onClick={onOpenImporterModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm shadow-indigo-600/20 transition"
          >
            <Code className="w-3.5 h-3.5" />
            <span>Import HTML</span>
          </button>
        </div>
      </div>

      {/* Screen Navigator Tabs Bar */}
      <div className="px-4 py-1.5 bg-slate-50/80 border-t border-slate-200/80 flex items-center justify-between gap-4 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 mr-1">
            Screens:
          </span>
          {activeSuite.screens.map((screen, idx) => {
            const isActive = activeScreen.id === screen.id;
            return (
              <button
                key={screen.id}
                onClick={() => onSelectScreen(screen.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-150 ${isActive ? 'bg-white text-indigo-600 shadow-sm border border-slate-200/90' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'}`}
              >
                <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-mono ${isActive ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                  {idx + 1}
                </span>
                <span>{screen.title}</span>
                {screen.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-medium ${isActive ? 'bg-indigo-50 text-indigo-700' : 'bg-slate-200/60 text-slate-500'}`}>
                    {screen.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-500 shrink-0">
          <span className="font-medium text-slate-700">{activeScreen.category}</span>
          <span>&bull;</span>
          <span>{activeScreen.description}</span>
        </div>
      </div>
    </header>
  );
};
