import React, { useState } from 'react';
import { 
  X, Code, Sparkles, Image as ImageIcon, CheckCircle, 
  ArrowRight, FileText, Upload
} from 'lucide-react';
import { STARTER_HTML_SNIPPETS } from '../data/sampleSuites';
import { extractHtmlMetadata } from '../utils/htmlParser';
import { ExtractedHtmlData } from '../types';

interface HtmlImporterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (data: ExtractedHtmlData) => void;
}

export const HtmlImporterModal: React.FC<HtmlImporterModalProps> = ({
  isOpen,
  onClose,
  onImport,
}) => {
  const [htmlInput, setHtmlInput] = useState(STARTER_HTML_SNIPPETS[0].html);
  const [previewData, setPreviewData] = useState<ExtractedHtmlData>(() => 
    extractHtmlMetadata(STARTER_HTML_SNIPPETS[0].html)
  );

  if (!isOpen) return null;

  const handleInputChange = (text: string) => {
    setHtmlInput(text);
    const parsed = extractHtmlMetadata(text);
    setPreviewData(parsed);
  };

  const handleApplyPreset = (snippetHtml: string) => {
    setHtmlInput(snippetHtml);
    const parsed = extractHtmlMetadata(snippetHtml);
    setPreviewData(parsed);
  };

  const handleConfirmImport = () => {
    const finalData = extractHtmlMetadata(htmlInput);
    onImport(finalData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Import HTML &amp; Extract Hotlinks</h2>
              <p className="text-xs text-slate-500">Paste your screen markup or select an existing template below.</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Preset Snippets bar */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Instant Starter HTML Snippets
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {STARTER_HTML_SNIPPETS.map((snippet, idx) => (
                <button
                  key={idx}
                  onClick={() => handleApplyPreset(snippet.html)}
                  className="text-left p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-indigo-50/50 hover:border-indigo-300 transition group flex flex-col justify-between"
                >
                  <div>
                    <div className="font-semibold text-xs text-slate-900 group-hover:text-indigo-600">
                      {snippet.name}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      {snippet.description}
                    </div>
                  </div>
                  <span className="text-[10px] text-indigo-600 font-medium mt-2">
                    Use Snippet &rarr;
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* HTML Textarea */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Raw HTML Markup
              </label>
              <span className="text-xs text-slate-400 font-mono">
                Supports &lt;img src="..."&gt;, Tailwind, and CSS
              </span>
            </div>
            <textarea
              rows={8}
              value={htmlInput}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="<section class='p-8 bg-slate-900 text-white'>&#10;  <img src='https://...' />&#10;</section>"
              className="w-full bg-slate-900 text-slate-100 font-mono text-xs p-4 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Real-time Extracted Stats Card */}
          <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100 p-4">
            <div className="text-xs font-bold text-indigo-950 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              Live Parser Intelligence
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-white p-3 rounded-xl border border-indigo-100 shadow-2xs">
                <div className="text-xl font-bold text-indigo-600">{previewData.imageUrls.length}</div>
                <div className="text-[11px] text-slate-600 font-medium">Hotlinked Images</div>
              </div>
              <div className="bg-white p-3 rounded-xl border border-indigo-100 shadow-2xs">
                <div className="text-xl font-bold text-slate-900">{previewData.headings.length}</div>
                <div className="text-[11px] text-slate-600 font-medium">Headings Found</div>
              </div>
              <div className="bg-white p-3 rounded-xl border border-indigo-100 shadow-2xs">
                <div className="text-xl font-bold text-slate-900">{previewData.buttonTexts.length}</div>
                <div className="text-[11px] text-slate-600 font-medium">Buttons &amp; Links</div>
              </div>
            </div>

            {/* Extracted Images thumbnail strip */}
            {previewData.imageUrls.length > 0 && (
              <div className="mt-3 pt-3 border-t border-indigo-100/60">
                <div className="text-[11px] font-semibold text-slate-600 mb-2">Detected Image URLs:</div>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {previewData.imageUrls.map((url, i) => (
                    <img
                      key={i}
                      src={url}
                      alt="Extracted"
                      className="w-14 h-12 object-cover rounded-lg border border-indigo-200 shrink-0 bg-white"
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirmImport}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition flex items-center gap-2"
          >
            <span>Render Screen &amp; Hotlinks</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
