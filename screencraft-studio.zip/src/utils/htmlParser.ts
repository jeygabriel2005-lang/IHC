import { ExtractedHtmlData } from '../types';

export function extractHtmlMetadata(htmlString: string): ExtractedHtmlData {
  if (typeof window === 'undefined' || !htmlString) {
    return {
      rawHtml: htmlString || '',
      imageUrls: [],
      headings: [],
      links: [],
      paragraphs: [],
      buttonTexts: [],
      parsedAt: new Date(),
    };
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlString, 'text/html');

  // Extract images from <img> tags
  const imgElements = Array.from(doc.querySelectorAll('img'));
  const imgUrls: string[] = [];

  imgElements.forEach((img) => {
    const src = img.getAttribute('src');
    if (src && !imgUrls.includes(src)) {
      imgUrls.push(src);
    }
  });

  // Extract images from style attributes or inline CSS
  const elementsWithStyle = Array.from(doc.querySelectorAll('[style]'));
  elementsWithStyle.forEach((el) => {
    const style = el.getAttribute('style') || '';
    const match = style.match(/url\(['"]?(.*?)['"]?\)/i);
    if (match && match[1] && !imgUrls.includes(match[1])) {
      imgUrls.push(match[1]);
    }
  });

  // Extract generic image URLs from text regex if not caught
  const urlRegex = /(https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|webp|svg|gif)(?:\?[^\s"'<>]*)?)/gi;
  let textMatch: RegExpExecArray | null;
  while ((textMatch = urlRegex.exec(htmlString)) !== null) {
    const url = textMatch[1];
    if (!imgUrls.includes(url)) {
      imgUrls.push(url);
    }
  }

  // Extract Headings
  const headings: string[] = [];
  doc.querySelectorAll('h1, h2, h3, h4, h5, h6').forEach((h) => {
    const text = h.textContent?.trim();
    if (text && !headings.includes(text)) {
      headings.push(text);
    }
  });

  // Extract Buttons
  const buttonTexts: string[] = [];
  doc.querySelectorAll('button, a.btn, [role="button"]').forEach((b) => {
    const text = b.textContent?.trim();
    if (text && !buttonTexts.includes(text)) {
      buttonTexts.push(text);
    }
  });

  // Extract Links
  const links: string[] = [];
  doc.querySelectorAll('a[href]').forEach((a) => {
    const href = a.getAttribute('href');
    if (href && !href.startsWith('#') && !href.startsWith('javascript:') && !links.includes(href)) {
      links.push(href);
    }
  });

  // Extract Paragraphs
  const paragraphs: string[] = [];
  doc.querySelectorAll('p').forEach((p) => {
    const text = p.textContent?.trim();
    if (text && text.length > 10 && !paragraphs.includes(text)) {
      paragraphs.push(text.slice(0, 150));
    }
  });

  const pageTitle = doc.querySelector('title')?.textContent || headings[0] || 'Imported HTML Screen';

  return {
    rawHtml: htmlString,
    title: pageTitle,
    imageUrls: imgUrls,
    headings,
    links,
    paragraphs,
    buttonTexts,
    parsedAt: new Date(),
  };
}
