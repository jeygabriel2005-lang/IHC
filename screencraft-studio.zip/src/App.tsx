import React, { useState, useEffect } from 'react';
import { SAMPLE_SUITES, STARTER_HTML_SNIPPETS } from './data/sampleSuites';
import { AppSuite, AppScreen, ViewportMode, ExtractedHtmlData, HotlinkImage } from './types';
import { TopNav } from './components/TopNav';
import { DeviceFrame } from './components/DeviceFrame';
import { LuminaScreens } from './screens/LuminaScreens';
import { AuraScreens } from './screens/AuraScreens';
import { PulseScreens } from './screens/PulseScreens';
import { ImportedHtmlScreen } from './screens/ImportedHtmlScreen';
import { HtmlImporterModal } from './components/HtmlImporterModal';
import { HotlinkGalleryModal } from './components/HotlinkGalleryModal';
import { extractHtmlMetadata } from './utils/htmlParser';
import { Sparkles, Code, Image as ImageIcon } from 'lucide-react';

export default function App() {
  const [suites, setSuites] = useState<AppSuite[]>(SAMPLE_SUITES);
  const [activeSuiteId, setActiveSuiteId] = useState<string>('lumina-saas');
  const [activeScreenId, setActiveScreenId] = useState<string>('lumina-overview');
  const [viewportMode, setViewportMode] = useState<ViewportMode>('desktop');
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [bgTheme, setBgTheme] = useState<'slate' | 'charcoal' | 'cream' | 'grid'>('grid');

  // Modals state
  const [isImporterOpen, setIsImporterOpen] = useState(false);
  const [isHotlinkGalleryOpen, setIsHotlinkGalleryOpen] = useState(false);

  // Imported HTML state
  const [importedData, setImportedData] = useState<ExtractedHtmlData>(() =>
    extractHtmlMetadata(STARTER_HTML_SNIPPETS[0].html)
  );

  // Custom hotlinks added by user
  const [customHotlinks, setCustomHotlinks] = useState<HotlinkImage[]>([]);

  // Find active suite and screen
  const activeSuite = suites.find(s => s.id === activeSuiteId) || suites[0];
  const activeScreen = activeSuite.screens.find(s => s.id === activeScreenId) || activeSuite.screens[0];

  // Handle switching suite
  const handleSelectSuite = (suiteId: string) => {
    setActiveSuiteId(suiteId);
    const targetSuite = suites.find(s => s.id === suiteId);
    if (targetSuite && targetSuite.screens.length > 0) {
      setActiveScreenId(targetSuite.screens[0].id);
    }
  };

  // Handle importing new HTML snippet
  const handleImportHtml = (data: ExtractedHtmlData) => {
    setImportedData(data);

    // Create an imported screen and suite
    const importedHotlinks: HotlinkImage[] = data.imageUrls.map((url, i) => ({
      id: `imported-img-${i}`,
      url,
      title: `Extracted Asset ${i + 1}`,
      category: 'hero',
    }));

    const importedScreen: AppScreen = {
      id: 'imported-screen-main',
      title: data.title || 'Custom HTML Screen',
      description: `${data.imageUrls.length} hotlinks extracted from your HTML template`,
      category: 'Imported Screen',
      badge: `${data.imageUrls.length} Hotlinks`,
      hotlinkImages: importedHotlinks,
    };

    const customSuite: AppSuite = {
      id: 'imported-suite',
      name: 'Custom Imported HTML',
      tagline: 'Your custom screen markup with hotlinked CDN assets',
      themeColor: '#4f46e5',
      accentBg: 'bg-indigo-600',
      screens: [importedScreen],
    };

    setSuites(prev => {
      const filtered = prev.filter(s => s.id !== 'imported-suite');
      return [...filtered, customSuite];
    });

    setActiveSuiteId('imported-suite');
    setActiveScreenId('imported-screen-main');
  };

  // Add custom hotlink image
  const handleAddCustomHotlink = (url: string, title: string) => {
    const newAsset: HotlinkImage = {
      id: `custom-hotlink-${Date.now()}`,
      url,
      title,
      category: 'abstract',
    };
    setCustomHotlinks(prev => [newAsset, ...prev]);
  };

  // Aggregate all hotlinks for active suite + custom
  const allCurrentHotlinks: HotlinkImage[] = [
    ...activeScreen.hotlinkImages,
    ...customHotlinks,
  ];

  // Keyboard navigation shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing in textarea or input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key >= '1' && e.key <= '9') {
        const index = parseInt(e.key) - 1;
        if (activeSuite.screens[index]) {
          setActiveScreenId(activeSuite.screens[index].id);
        }
      } else if (e.key.toLowerCase() === 'd') {
        setViewportMode('desktop');
      } else if (e.key.toLowerCase() === 't') {
        setViewportMode('tablet');
      } else if (e.key.toLowerCase() === 'm') {
        setViewportMode('mobile');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeSuite]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900 selection:bg-indigo-500 selection:text-white">
      {/* Top Application Bar */}
      <TopNav
        suites={suites}
        activeSuite={activeSuite}
        onSelectSuite={handleSelectSuite}
        activeScreen={activeScreen}
        onSelectScreen={setActiveScreenId}
        viewportMode={viewportMode}
        onSetViewportMode={setViewportMode}
        zoomScale={zoomScale}
        onSetZoomScale={setZoomScale}
        bgTheme={bgTheme}
        onSetBgTheme={setBgTheme}
        onOpenImporterModal={() => setIsImporterOpen(true)}
        onOpenHotlinksModal={() => setIsHotlinkGalleryOpen(true)}
        hotlinksCount={allCurrentHotlinks.length}
      />

      {/* Main Viewport Workspace with Device Frame */}
      <main className="flex-1">
        <DeviceFrame
          mode={viewportMode}
          scale={zoomScale}
          bgTheme={bgTheme}
        >
          {activeSuite.id === 'lumina-saas' && (
            <LuminaScreens
              screenId={activeScreen.id}
              onOpenHotlinkModal={() => setIsHotlinkGalleryOpen(true)}
            />
          )}

          {activeSuite.id === 'aura-store' && (
            <AuraScreens
              screenId={activeScreen.id}
              onOpenHotlinkModal={() => setIsHotlinkGalleryOpen(true)}
              onSwitchScreen={setActiveScreenId}
            />
          )}

          {activeSuite.id === 'pulse-fintech' && (
            <PulseScreens
              screenId={activeScreen.id}
              onOpenHotlinkModal={() => setIsHotlinkGalleryOpen(true)}
            />
          )}

          {activeSuite.id === 'imported-suite' && (
            <ImportedHtmlScreen
              data={importedData}
              onOpenImporterModal={() => setIsImporterOpen(true)}
              onOpenHotlinksModal={() => setIsHotlinkGalleryOpen(true)}
            />
          )}
        </DeviceFrame>
      </main>

      {/* Floating Prompt Bar Helper */}
      <aside aria-label="Quick Action Helper" className="fixed bottom-4 right-4 z-30 max-w-sm hidden lg:block">
        <div className="bg-slate-900/90 backdrop-blur-md text-white p-3.5 rounded-2xl shadow-xl border border-slate-700 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <span className="text-slate-300">
              Have specific HTML or mockups?
            </span>
          </div>
          <button
            onClick={() => setIsImporterOpen(true)}
            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold shrink-0 transition"
          >
            Import HTML
          </button>
        </div>
      </aside>

      {/* HTML Importer Modal */}
      <HtmlImporterModal
        isOpen={isImporterOpen}
        onClose={() => setIsImporterOpen(false)}
        onImport={handleImportHtml}
      />

      {/* Hotlink CDN Gallery Modal */}
      <HotlinkGalleryModal
        isOpen={isHotlinkGalleryOpen}
        onClose={() => setIsHotlinkGalleryOpen(false)}
        activeSuiteImages={allCurrentHotlinks}
        onAddCustomHotlink={handleAddCustomHotlink}
      />
    </div>
  );
}
