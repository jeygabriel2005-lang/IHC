import React, { useState } from 'react';
import { 
  Code, Eye, Image as ImageIcon, Copy, Check, Sparkles, 
  ExternalLink, Layers, ArrowUpRight, FileCode
} from 'lucide-react';
import { ExtractedHtmlData } from '../types';

interface ImportedHtmlScreenProps {
  data: ExtractedHtmlData;
  onOpenImporterModal: () => void;
  onOpenHotlinksModal: () => void;
}

export const ImportedHtmlScreen: React.FC<ImportedHtmlScreenProps> = ({
  data,
  onOpenImporterModal,
  onOpenHotlinksModal,
}) => {
  const [viewMode, setViewMode] = useState<'preview' | 'code' | 'assets'>('preview');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(text);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner with Extracted Stats */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-indigo-50 text-indigo-600">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
              Imported Screen Blueprint
            </span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">
            {data.title || 'Dynamic HTML Screen'}
          </h1>
          <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <ImageIcon className="w-3.5 h-3.5 text-indigo-500" />
              <strong>{data.imageUrls.length}</strong> Hotlinked Images
            </span>
            <span>&bull;</span>
            <span><strong>{data.headings.length}</strong> Headings</span>
            <span>&bull;</span>
            <span><strong>{data.buttonTexts.length}</strong> Interactive Actions</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Mode Switcher */}
          <div className="bg-slate-100 p-1 rounded-xl flex text-xs font-semibold text-slate-600">
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewMode === 'preview' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
            >
              <Eye className="w-3.5 h-3.5" />
              Screen
            </button>
            <button
              onClick={() => setViewMode('assets')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewMode === 'assets' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              Hotlinks ({data.imageUrls.length})
            </button>
            <button
              onClick={() => setViewMode('code')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${viewMode === 'code' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
            >
              <Code className="w-3.5 h-3.5" />
              HTML
            </button>
          </div>

          <button
            onClick={onOpenImporterModal}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition"
          >
            Paste New HTML
          </button>
        </div>
      </div>

      {/* Rendered Preview Mode */}
      {viewMode === 'preview' && (
        <div className="space-y-6">
          {/* Extracted Hotlink Strip (if any images found) */}
          {data.imageUrls.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                  Hotlinked Images Extracted from HTML ({data.imageUrls.length})
                </span>
                <span className="text-[11px] text-slate-500">Click any image to copy hotlink URL</span>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
                {data.imageUrls.map((url, i) => (
                  <div
                    key={i}
                    onClick={() => handleCopy(url)}
                    className="group relative shrink-0 w-28 h-20 rounded-xl overflow-hidden border border-slate-200 cursor-pointer bg-white shadow-2xs hover:border-indigo-400 transition"
                  >
                    <img src={url} alt={`Extracted ${i}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition text-white text-[10px] font-semibold text-center p-1">
                      {copiedUrl === url ? (
                        <span className="flex items-center gap-1 text-emerald-300">
                          <Check className="w-3 h-3" /> Copied!
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <Copy className="w-3 h-3" /> Copy Link
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Sandboxed HTML container with Tailwind base support */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden min-h-[400px]">
            <div 
              className="imported-html-content p-4 sm:p-8"
              dangerouslySetInnerHTML={{ __html: data.rawHtml }} 
            />
          </div>
        </div>
      )}

      {/* Extracted Hotlinks Asset Inspector Mode */}
      {viewMode === 'assets' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-xs">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Extracted Hotlinked Image URLs</h2>
            <p className="text-xs text-slate-500">Every image detected from &lt;img src&gt;, CSS styles, and media links.</p>
          </div>

          {data.imageUrls.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              No images detected in this HTML snippet.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.imageUrls.map((url, index) => (
                <div key={index} className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
                  <div className="aspect-video relative bg-slate-100 overflow-hidden">
                    <img src={url} alt={`Asset ${index}`} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3 space-y-2">
                    <div className="text-[11px] font-mono text-slate-600 truncate bg-white p-2 rounded border border-slate-200">
                      {url}
                    </div>
                    <button
                      onClick={() => handleCopy(url)}
                      className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-slate-200 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-semibold text-slate-700 transition"
                    >
                      {copiedUrl === url ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">Copied URL</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Direct URL</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Raw HTML Source Code Mode */}
      {viewMode === 'code' && (
        <div className="bg-slate-950 rounded-2xl p-6 text-slate-200 font-mono text-xs shadow-xl space-y-4 border border-slate-800">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-slate-400 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-indigo-400" />
              Source HTML Template
            </span>
            <button
              onClick={() => handleCopy(data.rawHtml)}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs transition flex items-center gap-1.5"
            >
              {copiedUrl === data.rawHtml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedUrl === data.rawHtml ? 'Copied HTML' : 'Copy HTML'}
            </button>
          </div>
          <pre className="overflow-x-auto p-2 bg-slate-900/60 rounded-xl leading-relaxed whitespace-pre-wrap max-h-[500px]">
            {data.rawHtml}
          </pre>
        </div>
      )}
    </div>
  );
};
