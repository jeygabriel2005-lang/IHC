import React, { useState } from 'react';
import { 
  TrendingUp, Users, Zap, Image as ImageIcon, ArrowUpRight, 
  Download, Copy, Check, Filter, Layers, Sliders, ShieldCheck,
  Search, Bell, Sparkles, ExternalLink, HardDrive, RefreshCw
} from 'lucide-react';
import { HotlinkImage } from '../types';

interface LuminaScreenProps {
  screenId: string;
  onOpenHotlinkModal?: () => void;
  onSelectImage?: (img: HotlinkImage) => void;
}

export const LuminaScreens: React.FC<LuminaScreenProps> = ({ 
  screenId, 
  onOpenHotlinkModal,
  onSelectImage 
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'overview' | 'breakdown' | 'realtime'>('overview');
  const [selectedAsset, setSelectedAsset] = useState<HotlinkImage | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Screen 1: Executive Analytics
  if (screenId === 'lumina-overview') {
    return (
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Live System Telemetry</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mt-1">Executive Dashboard</h1>
            <p className="text-sm text-slate-500">Cross-region platform metrics and active CDN edge nodes.</p>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={onOpenHotlinkModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg shadow-sm hover:bg-slate-50 transition"
            >
              <ImageIcon className="w-4 h-4 text-indigo-600" />
              Manage Hotlinks
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 transition">
              <Sparkles className="w-3.5 h-3.5" />
              Run Sync
            </button>
          </div>
        </div>

        {/* Metric Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-2">
              <span>Annual Recurring Revenue</span>
              <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                <TrendingUp className="w-4 h-4" />
              </span>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight">$4,289,450</div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-medium text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>+24.8% vs last quarter</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-2">
              <span>Enterprise Teams</span>
              <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                <Users className="w-4 h-4" />
              </span>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight">1,842</div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-medium text-indigo-600">
              <span>99.2% Net Retention</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-2">
              <span>Global CDN Edge Latency</span>
              <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
                <Zap className="w-4 h-4" />
              </span>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight">12.4 ms</div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-medium text-slate-500">
              <span>Across 48 edge locations</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-2">
              <span>Hotlinked Assets Served</span>
              <span className="p-1.5 rounded-lg bg-sky-50 text-sky-600">
                <HardDrive className="w-4 h-4" />
              </span>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight">98,420</div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-medium text-emerald-600">
              <span>100% Cache hit ratio</span>
            </div>
          </div>
        </div>

        {/* Main Analytics + Live Feed Split */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chart & Performance Container */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold text-slate-900 text-base">Traffic & Ingestion Bandwidth</h3>
                <p className="text-xs text-slate-500">Global requests per second across edge pops</p>
              </div>
              <div className="flex p-1 bg-slate-100 rounded-lg text-xs font-medium text-slate-600">
                <button 
                  onClick={() => setActiveTab('overview')}
                  className={`px-3 py-1 rounded-md transition ${activeTab === 'overview' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
                >
                  Overview
                </button>
                <button 
                  onClick={() => setActiveTab('breakdown')}
                  className={`px-3 py-1 rounded-md transition ${activeTab === 'breakdown' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
                >
                  Geo Nodes
                </button>
                <button 
                  onClick={() => setActiveTab('realtime')}
                  className={`px-3 py-1 rounded-md transition ${activeTab === 'realtime' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
                >
                  Live RPS
                </button>
              </div>
            </div>

            {/* Visual Simulated Activity Chart */}
            <div className="h-64 flex items-end gap-2 pt-8 pb-2 px-2 border-b border-slate-100">
              {[45, 62, 58, 75, 82, 69, 88, 94, 76, 85, 91, 100, 84, 96, 110, 105, 120, 115, 128, 140].map((val, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                  <div 
                    className="w-full bg-indigo-100 group-hover:bg-indigo-600 rounded-t-sm transition-all duration-300 relative"
                    style={{ height: `${(val / 140) * 100}%` }}
                  >
                    <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] py-1 px-1.5 rounded pointer-events-none whitespace-nowrap z-10 transition">
                      {val * 142} req/s
                    </div>
                  </div>
                  <span className="text-[9px] text-slate-400 group-hover:text-indigo-600">{idx + 1}h</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-4 text-xs text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-indigo-600" />
                Edge Cached Assets (94.2%)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-slate-300" />
                Dynamic API SSR (5.8%)
              </span>
              <span className="text-indigo-600 font-medium cursor-pointer hover:underline">
                View Full APM Logs &rarr;
              </span>
            </div>
          </div>

          {/* Active Team & Hotlink Avatars Column */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900 text-base">Core Engineering Team</h3>
                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-medium">3 Online</span>
              </div>
              <p className="text-xs text-slate-500 mb-4">Key contributors actively monitoring hotlink performance & CDN throughput.</p>

              <div className="space-y-3">
                {[
                  {
                    name: 'Sarah Jenkins',
                    role: 'VP Product & Systems',
                    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
                    status: 'online',
                    commit: 'Optimized WebP conversion pipelines',
                  },
                  {
                    name: 'Alex Thorne',
                    role: 'Principal Cloud Architect',
                    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
                    status: 'online',
                    commit: 'Deployed Cloudflare origin shield',
                  },
                  {
                    name: 'Elena Vance',
                    role: 'Staff ML Engineer',
                    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
                    status: 'away',
                    commit: 'Trained layout token extractor',
                  },
                ].map((person, i) => (
                  <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-50 border border-slate-100 hover:bg-indigo-50/50 transition">
                    <div className="relative">
                      <img 
                        src={person.avatar} 
                        alt={person.name} 
                        className="w-10 h-10 rounded-full object-cover border border-white shadow-xs" 
                      />
                      <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white ${person.status === 'online' ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">{person.name}</div>
                      <div className="text-[11px] text-slate-500 truncate">{person.role}</div>
                      <div className="text-[10px] text-indigo-600 truncate mt-0.5">{person.commit}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 mt-4">
              <button 
                onClick={onOpenHotlinkModal}
                className="w-full text-center text-xs font-medium text-indigo-600 hover:text-indigo-700 py-1.5"
              >
                + View all hotlinked assets &rarr;
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Screen 2: Digital Asset Studio (Curated Photo Gallery)
  if (screenId === 'lumina-media') {
    const assets: HotlinkImage[] = [
      {
        id: 'media-1',
        url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
        title: 'Abstract Gradient Flow 01',
        category: 'abstract',
        aspectRatio: '16:9',
      },
      {
        id: 'media-2',
        url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
        title: 'Minimalist Architecture Villa',
        category: 'architecture',
        aspectRatio: '4:3',
      },
      {
        id: 'media-3',
        url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
        title: 'Silicon Circuit Topology',
        category: 'abstract',
        aspectRatio: '16:9',
      },
      {
        id: 'media-4',
        url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
        title: 'Alpine Lake Reflection',
        category: 'hero',
        aspectRatio: '16:9',
      },
      {
        id: 'media-5',
        url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80',
        title: 'Modern Glass Skyscraper',
        category: 'architecture',
        aspectRatio: '4:3',
      },
      {
        id: 'media-6',
        url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
        title: 'Prismatic Acrylic Art',
        category: 'abstract',
        aspectRatio: '1:1',
      },
    ];

    const filtered = selectedCategory === 'all' 
      ? assets 
      : assets.filter(a => a.category === selectedCategory);

    return (
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Asset CDN Manager</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mt-1">Digital Asset Studio</h1>
            <p className="text-sm text-slate-500">Live hotlinked CDN assets ready to use across your layouts.</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600">
              {['all', 'abstract', 'architecture', 'hero'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-md capitalize transition ${selectedCategory === cat ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((asset) => (
            <div 
              key={asset.id} 
              className="group bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md hover:border-indigo-300 transition-all flex flex-col"
            >
              <div className="relative aspect-video bg-slate-100 overflow-hidden">
                <img 
                  src={asset.url} 
                  alt={asset.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
                <span className="absolute top-2.5 left-2.5 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded capitalize">
                  {asset.category}
                </span>
                <span className="absolute top-2.5 right-2.5 bg-white/90 backdrop-blur-xs text-slate-800 text-[10px] font-mono px-2 py-0.5 rounded shadow-xs">
                  {asset.aspectRatio || '16:9'}
                </span>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-semibold text-slate-900 text-sm mb-1">{asset.title}</h3>
                  <p className="text-[11px] text-slate-500 font-mono truncate">{asset.url}</p>
                </div>

                <div className="flex items-center gap-2 pt-4 mt-3 border-t border-slate-100">
                  <button
                    onClick={() => copyToClipboard(asset.url, asset.id)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-600 rounded-lg text-xs font-medium transition"
                  >
                    {copiedId === asset.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-600">Copied URL</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Hotlink</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setSelectedAsset(asset)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                    title="Inspect Asset"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Inspector when clicked */}
        {selectedAsset && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
                <h3 className="font-bold text-slate-900">{selectedAsset.title}</h3>
                <button 
                  onClick={() => setSelectedAsset(null)}
                  className="text-slate-400 hover:text-slate-700 text-sm font-semibold p-1"
                >
                  ✕
                </button>
              </div>

              <img 
                src={selectedAsset.url} 
                alt={selectedAsset.title} 
                className="w-full max-h-80 object-cover rounded-xl mb-4 border border-slate-100" 
              />

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mb-4">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Direct Hotlink URL</span>
                <input 
                  type="text" 
                  readOnly 
                  value={selectedAsset.url} 
                  className="w-full text-xs bg-white border border-slate-200 rounded p-2 text-slate-700 font-mono"
                />
              </div>

              <div className="flex justify-end gap-3">
                <button 
                  onClick={() => copyToClipboard(selectedAsset.url, 'modal')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition"
                >
                  {copiedId === 'modal' ? 'Copied!' : 'Copy Image Link'}
                </button>
                <button 
                  onClick={() => setSelectedAsset(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Screen 3: Canvas & Layout Studio
  if (screenId === 'lumina-editor') {
    return (
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Layout Studio & Component Canvas</h1>
            <p className="text-sm text-slate-500">Design screen blueprints with responsive auto-layout tokens.</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-medium">Design Tokens v3</span>
          </div>
        </div>

        {/* Canvas Workspace Box */}
        <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden min-h-[420px] flex flex-col justify-between shadow-xl">
          <img 
            src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80" 
            alt="Workspace Glow" 
            className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none" 
          />

          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-rose-500" />
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="ml-2 text-xs font-mono text-slate-400">Canvas &bull; Frame: 1440 &times; 900</span>
            </div>
            <div className="flex gap-2">
              <button className="bg-white/10 hover:bg-white/20 text-xs px-3 py-1.5 rounded-lg border border-white/20 transition">
                Export Tokens
              </button>
            </div>
          </div>

          <div className="relative z-10 max-w-xl my-8">
            <span className="text-indigo-400 text-xs font-bold uppercase tracking-widest">Interactive Prototype</span>
            <h2 className="text-3xl font-extrabold tracking-tight mt-1 mb-3">Modular Layout Engine with Live Hotlinking</h2>
            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              Drop any HTML snippet into the Importer to parse elements, extract embedded image assets, and preview them inside responsive multi-device frames instantly.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={onOpenHotlinkModal}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-lg shadow-indigo-600/30 transition"
              >
                Browse Hotlinked Library
              </button>
            </div>
          </div>

          <div className="relative z-10 grid grid-cols-3 gap-4 pt-4 border-t border-white/10 text-xs text-slate-400">
            <div>Auto-Layout: Flex & Grid</div>
            <div>Hotlinked CDN: Enabled</div>
            <div>Responsive Modes: 3 Active</div>
          </div>
        </div>
      </div>
    );
  }

  // Screen 4: Workspace & Security
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl font-bold text-slate-900">Workspace & Organization Settings</h1>
        <p className="text-sm text-slate-500">Manage security credentials, API webhooks, and team roles.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <h3 className="font-semibold text-slate-900 text-sm">Security & Access Tokens</h3>
          <p className="text-xs text-slate-500">Keys used to authenticate incoming webhooks and automated layout updates.</p>

          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-700">Production Public Key</label>
            <div className="flex items-center gap-2">
              <input 
                type="text" 
                readOnly 
                value="pk_live_lumina_98f48c3b772" 
                className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-800"
              />
              <button 
                onClick={() => copyToClipboard('pk_live_lumina_98f48c3b772', 'pk')}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-medium text-slate-700"
              >
                {copiedId === 'pk' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-900 text-sm mb-4">Workspace Environment Banner</h3>
          <div className="relative h-44 rounded-xl overflow-hidden border border-slate-200">
            <img 
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80" 
              alt="Workspace" 
              className="w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent p-4 flex flex-col justify-end text-white">
              <div className="font-bold text-base">Lumina Global Studio HQ</div>
              <div className="text-xs text-slate-300">San Francisco, CA &bull; Primary Edge Zone</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
