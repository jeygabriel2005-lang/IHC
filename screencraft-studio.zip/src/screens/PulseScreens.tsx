import React, { useState } from 'react';
import { 
  CreditCard, ArrowUpRight, ArrowDownLeft, Eye, EyeOff, 
  Send, Plus, ShieldCheck, Lock, Unlock, Smartphone,
  SlidersHorizontal, Check, RefreshCw
} from 'lucide-react';

interface PulseScreenProps {
  screenId: string;
  onOpenHotlinkModal?: () => void;
}

export const PulseScreens: React.FC<PulseScreenProps> = ({ 
  screenId,
  onOpenHotlinkModal 
}) => {
  const [hideBalance, setHideBalance] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState<'USD' | 'EUR' | 'GBP'>('USD');
  const [isCardFlipped, setIsCardFlipped] = useState(false);
  const [isCardFrozen, setIsCardFrozen] = useState(false);
  const [dailyLimit, setDailyLimit] = useState(5000);
  const [transferSuccess, setTransferSuccess] = useState(false);

  const balances = {
    USD: { symbol: '$', val: '124,580.45', change: '+12.4%' },
    EUR: { symbol: '€', val: '115,240.20', change: '+8.1%' },
    GBP: { symbol: '£', val: '98,710.00', change: '+5.7%' },
  };

  const handleSimulateTransfer = () => {
    setTransferSuccess(true);
    setTimeout(() => setTransferSuccess(false), 2500);
  };

  // Screen 1: Treasury & Balances
  if (screenId === 'pulse-home') {
    return (
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        {transferSuccess && (
          <div className="bg-emerald-500 text-white p-3 rounded-xl shadow-lg flex items-center justify-between text-xs font-semibold">
            <span>Payment transfer of $500.00 dispatched via FedNow Realtime Rail.</span>
            <Check className="w-4 h-4" />
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-sky-500 animate-ping" />
              <span className="text-xs font-semibold text-sky-600 uppercase tracking-wider">Pulse Commercial Treasury</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mt-1">Global Balances & Vault</h1>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-slate-100 p-1 rounded-lg flex text-xs font-bold text-slate-600">
              {(['USD', 'EUR', 'GBP'] as const).map(curr => (
                <button
                  key={curr}
                  onClick={() => setSelectedCurrency(curr)}
                  className={`px-3 py-1 rounded-md transition ${selectedCurrency === curr ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'}`}
                >
                  {curr}
                </button>
              ))}
            </div>
            <button 
              onClick={() => setHideBalance(!hideBalance)}
              className="p-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition"
              title="Toggle Privacy"
            >
              {hideBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Card & Balance Spotlight Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Virtual Card 3D Perspective (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div 
              onClick={() => setIsCardFlipped(!isCardFlipped)}
              className="cursor-pointer group relative aspect-[1.586] w-full rounded-2xl p-6 text-white shadow-2xl transition-all duration-500 hover:scale-[1.02] flex flex-col justify-between overflow-hidden"
              style={{
                background: isCardFrozen 
                  ? 'linear-gradient(135deg, #334155 0%, #1e293b 100%)' 
                  : 'linear-gradient(135deg, #0f172a 0%, #0369a1 50%, #0284c7 100%)',
              }}
            >
              <img 
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80" 
                alt="Card Finish" 
                className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-color-dodge pointer-events-none" 
              />

              <div className="relative z-10 flex items-center justify-between">
                <span className="font-mono text-xs tracking-widest uppercase opacity-80">Pulse Platinum Metal</span>
                <span className="text-xs font-bold text-sky-300">
                  {isCardFrozen ? '❄️ FROZEN' : 'ACTIVE • FDIC INSURED'}
                </span>
              </div>

              <div className="relative z-10 font-mono text-lg sm:text-xl tracking-wider text-slate-100 my-auto">
                {isCardFlipped ? 'CVV: 894 • EXP: 09/30' : '•••• •••• •••• 4912'}
              </div>

              <div className="relative z-10 flex items-end justify-between">
                <div>
                  <div className="text-[10px] text-slate-300 uppercase tracking-wider font-semibold">Cardholder</div>
                  <div className="font-semibold text-sm text-white">JORDAN A. LEE</div>
                </div>
                <div className="font-extrabold italic text-lg tracking-tighter text-white">
                  VISA <span className="text-xs font-normal not-italic opacity-70">Signature</span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 text-center mt-2">
              Click the metallic card to flip &amp; reveal security codes.
            </p>
          </div>

          {/* Quick Balance & Realtime Actions (7 cols) */}
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-6">
            <div>
              <div className="text-xs text-slate-500 font-medium">Available Portfolio Liquidity</div>
              <div className="text-4xl font-extrabold text-slate-900 tracking-tight mt-1">
                {hideBalance ? '••••••••' : `${balances[selectedCurrency].symbol}${balances[selectedCurrency].val}`}
              </div>
              <div className="flex items-center gap-2 mt-2 text-xs font-semibold text-emerald-600">
                <ArrowUpRight className="w-4 h-4" />
                <span>{balances[selectedCurrency].change} Net return this statement</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <button 
                onClick={handleSimulateTransfer}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white transition gap-1.5"
              >
                <Send className="w-4 h-4 text-sky-400" />
                <span className="text-xs font-medium">Send Wire</span>
              </button>
              <button 
                onClick={handleSimulateTransfer}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 transition gap-1.5"
              >
                <ArrowDownLeft className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-medium">Request</span>
              </button>
              <button 
                onClick={() => setIsCardFrozen(!isCardFrozen)}
                className={`flex flex-col items-center justify-center p-3 rounded-xl transition gap-1.5 ${isCardFrozen ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'}`}
              >
                {isCardFrozen ? <Lock className="w-4 h-4 text-amber-600" /> : <Unlock className="w-4 h-4 text-slate-600" />}
                <span className="text-xs font-medium">{isCardFrozen ? 'Unfreeze' : 'Freeze Card'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Screen 2: Cashflow Insights & Merchant Receipts
  if (screenId === 'pulse-activity') {
    const merchants = [
      {
        name: 'Bistro Luminary',
        category: 'Fine Dining & Hospitality',
        amount: '-$142.50',
        date: 'Today, 1:15 PM',
        image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=150&q=80',
      },
      {
        name: 'Apex Footwear Flagship',
        category: 'Apparel & Lifestyle',
        amount: '-$210.00',
        date: 'Yesterday, 4:20 PM',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=150&q=80',
      },
      {
        name: 'Artisan Roastery',
        category: 'Food & Beverage',
        amount: '-$18.40',
        date: 'Nov 10, 8:45 AM',
        image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=150&q=80',
      },
    ];

    return (
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="pb-4 border-b border-slate-200">
          <h1 className="text-2xl font-bold text-slate-900">Cashflow & Verified Receipts</h1>
          <p className="text-xs text-slate-500">Real-time settlement data with direct hotlinked merchant location photography.</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 shadow-xs overflow-hidden">
          {merchants.map((m, idx) => (
            <div key={idx} className="p-4 flex items-center gap-4 hover:bg-slate-50/80 transition">
              <img 
                src={m.image} 
                alt={m.name} 
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 shadow-2xs" 
              />
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-slate-900 text-sm truncate">{m.name}</div>
                <div className="text-xs text-slate-500 truncate">{m.category} &bull; {m.date}</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900 text-sm">{m.amount}</div>
                <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-medium">
                  Settled
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Screen 3: Virtual Card Vault
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl font-bold text-slate-900">Virtual Card Vault</h1>
        <p className="text-xs text-slate-500">Configure single-use disposable debit cards and spending caps.</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-2">
            Daily Card Spending Limit: <span className="text-sky-600 font-bold">${dailyLimit.toLocaleString()}</span>
          </label>
          <input 
            type="range" 
            min="500" 
            max="15000" 
            step="500" 
            value={dailyLimit} 
            onChange={(e) => setDailyLimit(Number(e.target.value))}
            className="w-full accent-sky-600"
          />
        </div>

        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="flex items-center gap-3">
            <Smartphone className="w-5 h-5 text-slate-700" />
            <div>
              <div className="font-semibold text-slate-900 text-xs">Apple Pay &amp; Google Wallet Sync</div>
              <div className="text-[11px] text-slate-500">Device token active on iPhone 16 Pro</div>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
            Enrolled
          </span>
        </div>
      </div>
    </div>
  );
};
