import React, { useState } from 'react';
import { 
  ShoppingBag, Star, Heart, Check, ArrowRight, Truck, Shield, 
  RotateCcw, Sparkles, Plus, Minus, Trash2, MapPin, Phone, MessageSquare
} from 'lucide-react';

interface AuraScreenProps {
  screenId: string;
  onOpenHotlinkModal?: () => void;
  onSwitchScreen?: (screenId: string) => void;
}

export const AuraScreens: React.FC<AuraScreenProps> = ({ 
  screenId, 
  onOpenHotlinkModal,
  onSwitchScreen 
}) => {
  // Product state
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState('Obsidian');
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [addedToast, setAddedToast] = useState(false);

  // Cart state
  const [cartItems, setCartItems] = useState([
    {
      id: 1,
      name: 'Wireless Studio Headphones',
      color: 'Matte Obsidian',
      price: 280,
      qty: 1,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=300&q=80',
    },
    {
      id: 2,
      name: 'Nordic Chrono 40mm',
      color: 'Titanium Silver',
      price: 340,
      qty: 1,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=300&q=80',
    },
  ]);

  const productPhotos = [
    {
      url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1000&q=80',
      caption: 'Front 3/4 Acoustic View',
    },
    {
      url: 'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=1000&q=80',
      caption: 'Headband Memory Foam Detail',
    },
    {
      url: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=1000&q=80',
      caption: 'Collapsible Carrying Profile',
    },
    {
      url: 'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?auto=format&fit=crop&w=1000&q=80',
      caption: 'Studio Workstation Context',
    },
  ];

  const handleAddToCart = () => {
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2500);
  };

  const updateCartQty = (id: number, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.qty + delta);
        return { ...item, qty: newQty };
      }
      return item;
    }));
  };

  const removeCartItem = (id: number) => {
    setCartItems(prev => prev.filter(i => i.id !== id));
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.price * item.qty, 0);

  // Screen 1: Editorial Lookbook
  if (screenId === 'aura-lookbook') {
    return (
      <div className="space-y-12 pb-16 max-w-7xl mx-auto px-4 sm:px-6">
        {/* Hero Editorial Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-stone-900 min-h-[460px] flex items-end p-8 sm:p-12 shadow-2xl">
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1400&q=80" 
            alt="Editorial Living Lookbook" 
            className="absolute inset-0 w-full h-full object-cover opacity-75 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />

          <div className="relative z-10 max-w-2xl text-white">
            <span className="inline-block px-3 py-1 bg-stone-100/20 backdrop-blur-md rounded-full text-xs font-medium uppercase tracking-widest text-stone-200 mb-4 border border-stone-100/30">
              Winter Collection 2026
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight mb-4 text-stone-50">
              The Art of Living Well
            </h1>
            <p className="text-stone-300 text-sm sm:text-base leading-relaxed mb-6 max-w-lg">
              Curated artisanal homeware, precision audio components, and Scandinavian timepieces crafted with sustainable materials.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onSwitchScreen?.('aura-product')}
                className="px-6 py-3 bg-stone-100 hover:bg-white text-stone-900 rounded-xl text-sm font-semibold shadow-lg transition flex items-center gap-2"
              >
                Explore Product Details
                <ArrowRight className="w-4 h-4" />
              </button>
              <button 
                onClick={onOpenHotlinkModal}
                className="px-5 py-3 bg-stone-800/80 hover:bg-stone-800 text-stone-200 rounded-xl text-sm font-medium border border-stone-700 transition"
              >
                Inspect Hotlinked Photos
              </button>
            </div>
          </div>
        </div>

        {/* Curated Grid Trio */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-stone-900">Featured Curations</h2>
              <p className="text-stone-500 text-sm">Directly hotlinked assets from verified studio photographers.</p>
            </div>
            <span className="text-stone-900 font-medium text-xs cursor-pointer hover:underline">
              View All 24 Pieces &rarr;
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: 'Handcrafted Ceramic Vessel',
                price: '$120',
                category: 'Ceramics',
                img: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80',
              },
              {
                title: 'Wireless Studio Headphones',
                price: '$280',
                category: 'Acoustics',
                img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
              },
              {
                title: 'Minimalist Chrono Watch',
                price: '$340',
                category: 'Horology',
                img: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
              },
            ].map((prod, idx) => (
              <div 
                key={idx} 
                onClick={() => onSwitchScreen?.('aura-product')}
                className="group cursor-pointer bg-stone-50 rounded-2xl overflow-hidden border border-stone-200/80 hover:border-stone-400 transition-all hover:shadow-lg flex flex-col"
              >
                <div className="relative aspect-square bg-stone-100 overflow-hidden">
                  <img 
                    src={prod.img} 
                    alt={prod.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500" 
                  />
                  <span className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[11px] px-2.5 py-0.5 rounded-full font-medium">
                    {prod.category}
                  </span>
                </div>
                <div className="p-5 flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-stone-900 text-sm group-hover:text-emerald-700 transition">
                      {prod.title}
                    </h3>
                    <p className="text-stone-500 text-xs mt-0.5">Crafted in Small Batches</p>
                  </div>
                  <span className="font-bold text-stone-900 text-base">{prod.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Screen 2: Product Detail & Gallery
  if (screenId === 'aura-product') {
    return (
      <div className="p-6 max-w-7xl mx-auto space-y-8">
        {/* Added to cart toast */}
        {addedToast && (
          <div className="fixed top-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-stone-700 animate-bounce">
            <Check className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-medium">Added to Bag successfully!</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Photos Container (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="relative aspect-square sm:aspect-4/3 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-sm">
              <img 
                src={productPhotos[selectedPhotoIndex].url} 
                alt="Product View" 
                className="w-full h-full object-cover transition-all duration-300"
              />
              <span className="absolute top-4 left-4 bg-stone-900/80 backdrop-blur-xs text-white text-xs px-3 py-1 rounded-full font-medium">
                {productPhotos[selectedPhotoIndex].caption}
              </span>
              <button 
                onClick={() => setIsWishlisted(!isWishlisted)}
                className="absolute top-4 right-4 p-2.5 bg-white/90 backdrop-blur-xs hover:bg-white rounded-full shadow-md transition"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'text-rose-500 fill-rose-500' : 'text-stone-700'}`} />
              </button>
            </div>

            {/* Thumbnails row */}
            <div className="grid grid-cols-4 gap-3">
              {productPhotos.map((photo, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedPhotoIndex(index)}
                  className={`relative aspect-square rounded-xl overflow-hidden border-2 transition ${selectedPhotoIndex === index ? 'border-stone-900 ring-2 ring-stone-900/20 shadow-sm' : 'border-stone-200 opacity-70 hover:opacity-100'}`}
                >
                  <img src={photo.url} alt={`Thumbnail ${index}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Specifications & Order (5 cols) */}
          <div className="lg:col-span-5 space-y-6 bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="flex text-amber-500 text-xs">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <span className="text-xs text-stone-500 font-medium">(148 verified reviews)</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
                Wireless Studio Headphones
              </h1>
              <p className="text-stone-500 text-xs mt-1">Series 4 Reference Acoustic System</p>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold text-stone-900">$280.00</span>
              <span className="text-stone-400 line-through text-sm">$320.00</span>
              <span className="text-xs bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full font-semibold border border-emerald-200">
                In Stock &bull; Free Express Delivery
              </span>
            </div>

            <p className="text-stone-600 text-sm leading-relaxed border-t border-b border-stone-100 py-4">
              Constructed with custom 40mm beryllium diaphragm drivers, memory foam lambskin earcups, and dual active noise cancellation microphones.
            </p>

            {/* Color variants */}
            <div>
              <label className="text-xs font-semibold text-stone-900 block mb-2">
                Finish Color: <span className="text-stone-500 font-normal">{selectedColor}</span>
              </label>
              <div className="flex gap-2.5">
                {[
                  { name: 'Obsidian', colorClass: 'bg-stone-900' },
                  { name: 'Chalk White', colorClass: 'bg-stone-100 border border-stone-300' },
                  { name: 'Titanium Gray', colorClass: 'bg-stone-400' },
                  { name: 'Forest Moss', colorClass: 'bg-emerald-800' },
                ].map((col) => (
                  <button
                    key={col.name}
                    onClick={() => setSelectedColor(col.name)}
                    className={`h-9 w-9 rounded-full ${col.colorClass} flex items-center justify-center transition ${selectedColor === col.name ? 'ring-2 ring-stone-900 ring-offset-2 scale-105' : 'hover:scale-105'}`}
                    title={col.name}
                  >
                    {selectedColor === col.name && (
                      <Check className={`w-4 h-4 ${col.name === 'Chalk White' ? 'text-stone-900' : 'text-white'}`} />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity and Actions */}
            <div className="space-y-3 pt-2">
              <div className="flex gap-3">
                <div className="flex items-center border border-stone-200 rounded-xl px-3 py-2 bg-stone-50">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1 text-stone-500 hover:text-stone-900"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-10 text-center font-bold text-sm text-stone-900">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1 text-stone-500 hover:text-stone-900"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-stone-900 hover:bg-stone-800 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Bag</span>
                </button>
              </div>

              <button 
                onClick={() => onSwitchScreen?.('aura-bag')}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-6 rounded-xl transition text-center text-sm shadow-sm"
              >
                Instant Checkout with 1-Click
              </button>
            </div>

            {/* Guarantee badges */}
            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-stone-100 text-[11px] text-stone-500 text-center">
              <div className="p-2 bg-stone-50 rounded-lg">
                <Truck className="w-4 h-4 mx-auto mb-1 text-stone-700" />
                2-Day Shipping
              </div>
              <div className="p-2 bg-stone-50 rounded-lg">
                <Shield className="w-4 h-4 mx-auto mb-1 text-stone-700" />
                2-Year Warranty
              </div>
              <div className="p-2 bg-stone-50 rounded-lg">
                <RotateCcw className="w-4 h-4 mx-auto mb-1 text-stone-700" />
                30-Day Returns
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Screen 3: Shopping Bag & Checkout Drawer
  if (screenId === 'aura-bag') {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div>
            <h1 className="text-2xl font-bold text-stone-900">Your Shopping Bag</h1>
            <p className="text-xs text-stone-500">{cartItems.length} curated pieces ready for shipment.</p>
          </div>
          <button 
            onClick={() => onSwitchScreen?.('aura-tracking')}
            className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1"
          >
            Track Existing Orders &rarr;
          </button>
        </div>

        {/* Free shipping banner */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3">
          <div className="p-2 bg-emerald-100 rounded-lg text-emerald-800">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="text-xs text-emerald-900">
            <span className="font-bold">Complimentary Express Shipping Unlocked!</span> Your order qualifies for insured white-glove courier delivery.
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Cart items list (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-4 p-4 bg-white rounded-xl border border-stone-200 shadow-2xs items-center">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-20 h-20 object-cover rounded-lg border border-stone-100 bg-stone-50"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-stone-900 text-sm truncate">{item.name}</h3>
                  <p className="text-xs text-stone-500 mb-2">{item.color}</p>
                  
                  <div className="flex items-center gap-2">
                    <div className="flex items-center border border-stone-200 rounded-lg px-2 py-0.5 bg-stone-50 text-xs">
                      <button onClick={() => updateCartQty(item.id, -1)} className="px-1 text-stone-500 hover:text-stone-900">-</button>
                      <span className="px-2 font-bold text-stone-800">{item.qty}</span>
                      <button onClick={() => updateCartQty(item.id, 1)} className="px-1 text-stone-500 hover:text-stone-900">+</button>
                    </div>
                    <button 
                      onClick={() => removeCartItem(item.id)}
                      className="text-stone-400 hover:text-rose-600 p-1 transition"
                      title="Remove"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-stone-900 text-base">${item.price * item.qty}</div>
                  <div className="text-[11px] text-stone-400">${item.price} each</div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary & Checkout Card (5 cols) */}
          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <h3 className="font-bold text-stone-900 text-base">Order Summary</h3>

            <div className="space-y-2 text-xs text-stone-600 border-b border-stone-100 pb-4">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-stone-900">${cartSubtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Express Shipping</span>
                <span className="font-semibold text-emerald-600">FREE</span>
              </div>
              <div className="flex justify-between">
                <span>Sales Tax (CA 7.5%)</span>
                <span className="font-semibold text-stone-900">${(cartSubtotal * 0.075).toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between text-base font-extrabold text-stone-900">
              <span>Total Amount</span>
              <span>${(cartSubtotal * 1.075).toFixed(2)}</span>
            </div>

            <button 
              onClick={() => onSwitchScreen?.('aura-tracking')}
              className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg transition flex items-center justify-center gap-2"
            >
              <span>Place Order (${(cartSubtotal * 1.075).toFixed(2)})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Screen 4: Order Status & Live Shipment Tracker
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-stone-200">
        <div>
          <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">Tracking #AUR-89240</span>
          <h1 className="text-2xl font-bold text-stone-900 mt-1">Package in Transit</h1>
          <p className="text-xs text-stone-500">Estimated delivery: Today by 3:45 PM</p>
        </div>
        <span className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-semibold">
          On Schedule
        </span>
      </div>

      {/* Progress timeline */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          {[
            { step: 'Order Placed', time: '10:15 AM', done: true },
            { step: 'Quality Verified', time: '11:40 AM', done: true },
            { step: 'Out for Courier', time: '1:20 PM', done: true },
            { step: 'Delivered', time: 'Pending', done: false },
          ].map((s, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs mb-2 ${s.done ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-500'}`}>
                {s.done ? <Check className="w-4 h-4" /> : i + 1}
              </div>
              <span className="font-semibold text-stone-900">{s.step}</span>
              <span className="text-[10px] text-stone-400">{s.time}</span>
            </div>
          ))}
        </div>

        {/* Courier Driver card */}
        <div className="flex items-center justify-between p-4 bg-stone-50 rounded-xl border border-stone-200 mt-4">
          <div className="flex items-center gap-3">
            <img 
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80" 
              alt="Marcus Bell" 
              className="w-12 h-12 rounded-full object-cover border border-white shadow-xs" 
            />
            <div>
              <div className="font-bold text-stone-900 text-sm">Marcus Bell</div>
              <div className="text-xs text-stone-500">Dedicated Courier Driver &bull; 4.98 ★</div>
              <div className="text-[10px] text-emerald-700 font-medium">3 stops away from your location</div>
            </div>
          </div>

          <div className="flex gap-2">
            <button className="p-2 bg-white hover:bg-stone-100 rounded-lg border border-stone-200 text-stone-700 transition">
              <Phone className="w-4 h-4" />
            </button>
            <button className="p-2 bg-white hover:bg-stone-100 rounded-lg border border-stone-200 text-stone-700 transition">
              <MessageSquare className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
