import { AppSuite } from '../types';

export const SAMPLE_SUITES: AppSuite[] = [
  {
    id: 'lumina-saas',
    name: 'Lumina Cloud Platform',
    tagline: 'Modern AI & Analytics Workspace with Media Management',
    themeColor: '#6366f1',
    accentBg: 'bg-indigo-600',
    screens: [
      {
        id: 'lumina-overview',
        title: 'Executive Analytics',
        description: 'Real-time platform metrics, revenue tracking, user retention and active pipelines.',
        category: 'Analytics & Dashboards',
        badge: 'Live Data',
        hotlinkImages: [
          {
            id: 'avatar-1',
            url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
            title: 'Sarah Jenkins (VP Product)',
            category: 'avatar',
          },
          {
            id: 'avatar-2',
            url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
            title: 'Alex Thorne (Lead Architect)',
            category: 'avatar',
          },
          {
            id: 'avatar-3',
            url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
            title: 'Elena Vance (Data Science)',
            category: 'avatar',
          },
          {
            id: 'hero-chart',
            url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
            title: 'Analytics Background Texture',
            category: 'hero',
          },
        ],
      },
      {
        id: 'lumina-media',
        title: 'Digital Asset Studio',
        description: 'Curated high-res photo gallery with real-time hotlinked CDN assets and tagging.',
        category: 'Media & Assets',
        badge: 'Hotlinked CDN',
        hotlinkImages: [
          {
            id: 'media-1',
            url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
            title: 'Abstract Gradient Flow 01',
            category: 'abstract',
          },
          {
            id: 'media-2',
            url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
            title: 'Minimalist Architecture Villa',
            category: 'architecture',
          },
          {
            id: 'media-3',
            url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
            title: 'Silicon Circuit Topology',
            category: 'abstract',
          },
          {
            id: 'media-4',
            url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
            title: 'Alpine Lake Reflection',
            category: 'hero',
          },
          {
            id: 'media-5',
            url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80',
            title: 'Modern Glass Skyscraper',
            category: 'architecture',
          },
          {
            id: 'media-6',
            url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
            title: 'Prismatic Acrylic Art',
            category: 'abstract',
          },
        ],
      },
      {
        id: 'lumina-editor',
        title: 'Canvas & Layout Studio',
        description: 'Interactive component canvas with layer panels, responsive viewports, and styling tokens.',
        category: 'Design Tools',
        badge: 'Interactive',
        hotlinkImages: [
          {
            id: 'artboard-bg',
            url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
            title: 'Workspace Background Grid',
            category: 'abstract',
          },
        ],
      },
      {
        id: 'lumina-settings',
        title: 'Workspace & Security',
        description: 'Enterprise team permissions, API key tokens, webhooks, and billing tiers.',
        category: 'Organization',
        hotlinkImages: [
          {
            id: 'org-banner',
            url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
            title: 'Lumina HQ Interior',
            category: 'architecture',
          },
        ],
      },
    ],
  },
  {
    id: 'aura-store',
    name: 'Aura Artisanal Store',
    tagline: 'High-end design showcase and curated lifestyle store',
    themeColor: '#059669',
    accentBg: 'bg-emerald-600',
    screens: [
      {
        id: 'aura-lookbook',
        title: 'Editorial Lookbook',
        description: 'Atmospheric hero banners, curated collections, and lifestyle editorial imagery.',
        category: 'Discovery',
        badge: 'Curated 2026',
        hotlinkImages: [
          {
            id: 'lookbook-hero',
            url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
            title: 'Autumn Nordic Living Concept',
            category: 'hero',
          },
          {
            id: 'collection-1',
            url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80',
            title: 'Handcrafted Ceramic Vessel',
            category: 'product',
          },
          {
            id: 'collection-2',
            url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
            title: 'Precision Acoustic Studio Monitor',
            category: 'product',
          },
          {
            id: 'collection-3',
            url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
            title: 'Analog Minimalist Timepiece',
            category: 'product',
          },
        ],
      },
      {
        id: 'aura-product',
        title: 'Product Detail & Gallery',
        description: 'Multi-angle image carousel, material specifications, color variants, and purchase actions.',
        category: 'E-Commerce',
        badge: 'Interactive Gallery',
        hotlinkImages: [
          {
            id: 'prod-main',
            url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
            title: 'Wireless Studio Headphones (Matte Obsidian)',
            category: 'product',
          },
          {
            id: 'prod-angle-1',
            url: 'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=80',
            title: 'Cushion & Leather Texture',
            category: 'product',
          },
          {
            id: 'prod-angle-2',
            url: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=80',
            title: 'Foldable Profile & Case',
            category: 'product',
          },
          {
            id: 'prod-angle-3',
            url: 'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?auto=format&fit=crop&w=900&q=80',
            title: 'Lifestyle Soundscape Setting',
            category: 'hero',
          },
        ],
      },
      {
        id: 'aura-bag',
        title: 'Shopping Bag & Checkout',
        description: 'Express drawer checkout, line item summary, discount vouchers, and shipping estimator.',
        category: 'Checkout',
        hotlinkImages: [
          {
            id: 'bag-item-1',
            url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=200&q=80',
            title: 'Studio Headphones',
            category: 'product',
          },
          {
            id: 'bag-item-2',
            url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=200&q=80',
            title: 'Classic Chrono Watch',
            category: 'product',
          },
        ],
      },
      {
        id: 'aura-tracking',
        title: 'Live Order Tracking',
        description: 'Courier dispatch milestones, estimated delivery timeline, and delivery driver verification.',
        category: 'Fulfillment',
        hotlinkImages: [
          {
            id: 'courier-avatar',
            url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
            title: 'Marcus Bell (Courier Partner)',
            category: 'avatar',
          },
        ],
      },
    ],
  },
  {
    id: 'pulse-fintech',
    name: 'Pulse Capital & Pay',
    tagline: 'Next-generation digital banking and global multi-currency treasury',
    themeColor: '#0ea5e9',
    accentBg: 'bg-sky-600',
    screens: [
      {
        id: 'pulse-home',
        title: 'Treasury & Balances',
        description: 'Multi-currency balances, virtual card flip, quick send/receive, and recent settlement feed.',
        category: 'Banking',
        badge: 'Secure FDIC',
        hotlinkImages: [
          {
            id: 'user-user',
            url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
            title: 'Jordan Lee (Account Holder)',
            category: 'avatar',
          },
          {
            id: 'card-texture',
            url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
            title: 'Black Platinum Metal Hologram',
            category: 'abstract',
          },
        ],
      },
      {
        id: 'pulse-activity',
        title: 'Cashflow Insights',
        description: 'Categorized expenditure, merchant avatar receipts, spending analytics, and recurring budget limits.',
        category: 'Cash Flow',
        hotlinkImages: [
          {
            id: 'merchant-1',
            url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=150&q=80',
            title: 'Bistro Luminary',
            category: 'architecture',
          },
          {
            id: 'merchant-2',
            url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=150&q=80',
            title: 'Apex Footwear Flagship',
            category: 'product',
          },
          {
            id: 'merchant-3',
            url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=150&q=80',
            title: 'Artisan Roastery',
            category: 'architecture',
          },
        ],
      },
      {
        id: 'pulse-cards',
        title: 'Virtual Card Vault',
        description: 'Disposable single-use cards, Apple Pay instant provisioning, PIN change, and geographic locks.',
        category: 'Security',
        hotlinkImages: [
          {
            id: 'card-bg-emerald',
            url: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80',
            title: 'Emerald Wave Metal Finish',
            category: 'abstract',
          },
          {
            id: 'card-bg-violet',
            url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=800&q=80',
            title: 'Neon Gradient Card Surface',
            category: 'abstract',
          },
        ],
      },
    ],
  },
];

export const POPULAR_HOTLINK_PRESETS = [
  {
    category: 'Avatars & People',
    items: [
      { name: 'Sarah (Creative Director)', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80' },
      { name: 'Marcus (Tech Lead)', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
      { name: 'Aaliyah (Product Designer)', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80' },
      { name: 'Devon (Growth Officer)', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' },
    ],
  },
  {
    category: 'Hero & Architectural Backgrounds',
    items: [
      { name: 'Minimalist Concrete Villa', url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80' },
      { name: 'Metropolitan Glass Tower', url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80' },
      { name: 'Modern Scandinavian Workspace', url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80' },
      { name: 'Alpine Misty Summit', url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80' },
    ],
  },
  {
    category: 'Products & Lifestyle',
    items: [
      { name: 'Matte Obsidian Headphones', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80' },
      { name: 'Minimalist Chrono Watch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80' },
      { name: 'Handcrafted Ceramic Jug', url: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
      { name: 'Precision Mechanical Keyboard', url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=600&q=80' },
    ],
  },
  {
    category: 'Abstract & 3D Textures',
    items: [
      { name: 'Prismatic Gradient Waves', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80' },
      { name: 'Iridescent Glass Sphere', url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80' },
      { name: 'Cybernetic Emerald Flow', url: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80' },
      { name: 'Dark Metallic Carbon Fiber', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=800&q=80' },
    ],
  },
];

export const STARTER_HTML_SNIPPETS = [
  {
    name: 'Modern SaaS Hero & Feature Trio',
    description: 'Header with brand, badge, headline, CTA buttons and three hotlinked feature cards.',
    html: `<header class="bg-slate-900 text-white py-16 px-6 text-center">
  <div class="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 text-indigo-400 rounded-full text-xs font-semibold mb-4 border border-indigo-500/30">
    <span>✨ New Generation Platform</span>
  </div>
  <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 text-white">
    Build faster with intelligent screens
  </h1>
  <p class="text-slate-400 max-w-xl mx-auto text-base mb-8">
    Craft high-performance user interfaces with extracted hotlinks, modular blocks, and real-time responsiveness.
  </p>
  <div class="flex justify-center gap-4">
    <button class="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-6 py-2.5 rounded-lg transition shadow-lg shadow-indigo-600/30">
      Get Started Free
    </button>
    <button class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium px-6 py-2.5 rounded-lg border border-slate-700 transition">
      Explore Showcase
    </button>
  </div>
</header>

<section class="max-w-6xl mx-auto py-12 px-6">
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition">
      <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80" alt="Design System" class="w-full h-44 object-cover" />
      <div class="p-5">
        <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Design System</span>
        <h3 class="text-lg font-bold text-slate-900 mt-1 mb-2">Automated Token Engine</h3>
        <p class="text-slate-600 text-sm">Export verified CSS variable systems directly into production frameworks without manual friction.</p>
      </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition">
      <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80" alt="Architecture" class="w-full h-44 object-cover" />
      <div class="p-5">
        <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Infrastructure</span>
        <h3 class="text-lg font-bold text-slate-900 mt-1 mb-2">Global Edge Delivery</h3>
        <p class="text-slate-600 text-sm">Zero-cold-start edge compute delivers sub-15ms asset resolution worldwide with automated cache purging.</p>
      </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition">
      <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80" alt="Hardware" class="w-full h-44 object-cover" />
      <div class="p-5">
        <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">Components</span>
        <h3 class="text-lg font-bold text-slate-900 mt-1 mb-2">Studio-Grade Audio</h3>
        <p class="text-slate-600 text-sm">Engineered with custom beryllium acoustic drivers and ultra-low noise active cancellation circuits.</p>
      </div>
    </div>
  </div>
</section>`,
  },
  {
    name: 'Curated E-Commerce Product Spotlight',
    description: 'Hero product banner with thumbnail gallery, pricing badge, and customer review avatars.',
    html: `<div class="max-w-4xl mx-auto p-6 bg-stone-50 rounded-2xl border border-stone-200">
  <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
    <div class="relative">
      <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80" alt="Nordic Timepiece" class="rounded-xl w-full shadow-lg object-cover h-80" />
      <span class="absolute top-3 left-3 bg-stone-900/90 text-white text-xs px-2.5 py-1 rounded-full font-medium">Limited Batch #042</span>
    </div>
    <div>
      <span class="text-emerald-700 font-semibold text-xs tracking-wider uppercase">In Stock • Fast Shipping</span>
      <h2 class="text-2xl font-bold text-stone-900 mt-1 mb-2">Nordic Chronograph 40mm</h2>
      <p class="text-stone-600 text-sm leading-relaxed mb-4">
        Constructed from surgical-grade 316L stainless steel, paired with vegetable-tanned Horween Italian calfskin and a domed sapphire crystal.
      </p>
      <div class="flex items-baseline gap-3 mb-6">
        <span class="text-3xl font-extrabold text-stone-900">$340</span>
        <span class="text-stone-400 line-through text-sm">$420</span>
        <span class="bg-emerald-100 text-emerald-800 text-xs px-2 py-0.5 rounded font-medium">Save 19%</span>
      </div>
      <div class="flex items-center gap-3 mb-6 p-3 bg-white rounded-lg border border-stone-200">
        <div class="flex -space-x-2">
          <img class="w-8 h-8 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80" alt="Customer 1" />
          <img class="w-8 h-8 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80" alt="Customer 2" />
          <img class="w-8 h-8 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80" alt="Customer 3" />
        </div>
        <span class="text-xs text-stone-600 font-medium">Rated 4.9/5 by 380+ collectors</span>
      </div>
      <div class="flex gap-3">
        <button class="flex-1 bg-stone-900 hover:bg-stone-800 text-white font-medium py-3 px-4 rounded-xl shadow transition text-center">
          Add to Cart
        </button>
        <button class="bg-stone-200 hover:bg-stone-300 text-stone-800 px-4 py-3 rounded-xl transition">
          ♥
        </button>
      </div>
    </div>
  </div>
</div>`,
  },
];
